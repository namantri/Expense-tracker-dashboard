import { configureStore } from "@reduxjs/toolkit";
import dataSlice from "./userData";
import selectedDataSlice from "./selectedData";
const store = configureStore({
  reducer: { data: dataSlice.reducer, selectedData: selectedDataSlice.reducer },
});
export default store;
