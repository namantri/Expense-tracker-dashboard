import React from 'react'
import "./ShowExtraData.css"
const ShowExtraData = () => {
  return (
    <div className='showExtraData-container'>ShowExtraData</div>
  )
}

export default ShowExtraData