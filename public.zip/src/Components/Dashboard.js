import React, { useEffect, useState } from "react";
import "./dashboard.css";
import { useSelector } from "react-redux";
const Dashboard = () => {
  const [totalExpense, setTotalExpense] = useState("");
  const [monthlyExpense, setMonthlyExpense] = useState("");
  const [dailyExpense, setDailyExpense] = useState("");
  const filteredData = useSelector((state) => state.selectedData.selectedData);
  const date = new Date();
//   {
//     filteredData && console.log(filteredData[0]?.date);
//   }

  const getTotalExpense = () => {
    var res = 0;
    for (var i = 0; i < filteredData.length; i++) {
      res += parseInt(filteredData[i].expense);
    }
    setTotalExpense(res);
  };
  const getMonthlyExpense = () => {
    var res = 0;
    for (var i = 0; i < filteredData.length; i++) {
      const userDate = new Date(filteredData[i].date);
      if (
        (userDate.getMonth() == date.getMonth()) &
        (userDate.getFullYear() == date.getFullYear())
      ) {
        res += parseInt(filteredData[i].expense);
      }
    }
    setMonthlyExpense(res);
  };
  const getTodaysExpense = () => {
    var res = 0;
    for (var i = 0; i < filteredData.length; i++) {
      const userDate = new Date(filteredData[i].date);
      console.log(userDate.getDate == date.getDate);
      if (userDate.getDate == date.getDate) {
        res += parseInt(filteredData[i].expense);
      }
    }
    setDailyExpense(res);
  };
  useEffect(() => {
    getTotalExpense();
    getMonthlyExpense();
    getTodaysExpense();
  }, [filteredData]);
  return (
    <div className="dashboard-container">
      <div className="dashboard">
        <h5>Dashboard</h5>
        <span>Hello, Naman Welcome to the Expense Dashboard</span>
      </div>
      <div className="card-container">
        <div className="total-expense card">
          <span>Total Expense</span>
          <h3>{totalExpense ? totalExpense : "- - - -"}</h3>
        </div>
        <div className="monthly-expense card">
          <span>Monthly Expense</span>
          <h3>{monthlyExpense ? monthlyExpense : "- - - -"}</h3>
        </div>
        <div className="todays-expense card">
          <span>Today's Expense</span>
          <h3>{dailyExpense ? dailyExpense : "- - - -"}</h3>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
